export const byName: string[] = [
  "Redesigns",
  "Refactors",
  "Components",
  "Landing pages",
  "Full website",
  "Open Graphs",
  "Social media assets",
];

export const designwork = byName.map((title) => ({ title }));
