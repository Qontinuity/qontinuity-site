export const byName: string[] = [
  "Components",
  "Blogs",
  "Design to code",
  "Landing pages",
  "Website templates",
  "Convert to Tailwind CSS",
  "Convert to Astro",
];

export const devwork = byName.map((title) => ({ title }));
